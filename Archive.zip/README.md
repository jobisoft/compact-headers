# compact-headers
About this Add-on:

Adds a twisty to the header area which toggles between compact and expanded headers.
Keyboard shortcut Alt-D toggles between compact and expanded headers.

Adds a context menu to the header area with options for the extension:
- Display compact headers on a single line.
- Show the To header on the first line in double line mode.
- Show the Cc header on the first line in double line mode.
- Show the Website from RSS feeds on the first line in double line mode.
- Show message tags on the second line in double line mode.
- Hide the header toolbar.
